#!/usr/bin/env python

import tkinter

top = tkinter.Tk()
label = tkinter.Label(top, text='Hello World!')
label.pack()
tkinter.mainloop()
